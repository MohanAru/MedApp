// ignore: file_names
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:medapp/BillerPage.dart';
import 'package:medapp/Inventry.dart';
import 'package:medapp/ManagerPage.dart';
import 'package:medapp/details.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextEditingController textController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  String _input = '';
  String input = '';
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  List? login;
  List? medicineMaster;
  List? stock;
  List loginhistory = [];
  SharedPreferences? sref;
  fetchData() async {
    sref = await SharedPreferences.getInstance();
    String data = sref!.getString('login') ?? '[]';
    String data2 = sref!.getString('medicineMaster') ?? '[]';
    String data1 = sref!.getString('stock') ?? '[]';
    String data3 = sref!.getString('login History') ?? '[]';
    if (medicineMaster == null || medicineMaster!.isEmpty) {
      medicineMaster = jsonDecode(data2);
      if (medicineMaster == null || medicineMaster!.isEmpty) {
        medicineMaster = medicineMasterList;
        sref!.setString('medicineMaster', jsonEncode(medicineMaster));
      }
    }

    if (stock == null || stock!.isEmpty) {
      stock = jsonDecode(data1);
      if (stock == null || stock!.isEmpty) {
        stock = stockList;
        sref!.setString('stock', jsonEncode(stock));
      }
    }
    if (login == null || login!.isEmpty) {
      login = jsonDecode(data);
      if (login == null || login!.isEmpty) {
        login = logindata;
        sref!.setString('login', jsonEncode(login));
      }
    }

    if (loginhistory.isEmpty) {
      loginhistory = jsonDecode(data3);
    }
    setState(() {});
  }

  Map author = {
    'UserId': 'vijay',
    'Pass': '123',
  };

  void handleLoginSuccess(String loginTime) {
    BillerPage.setLoginTime(loginTime);
    // Navigate to the next page or perform any other actions.
  }

  void _submit() {
    if (_formKey.currentState!.validate()) {
      for (var item in login!) {
        if (_input == 'manager' && input == item['password']) {
          Navigator.of(context).push(MaterialPageRoute(builder: (context) {
            return const ManagerPage();
          }));
        }
        if (_input == 'vijay' && input == item['password']) {
          Navigator.of(context).push(MaterialPageRoute(builder: (context) {
            return const BillerPage();
          }));
        }
        if (_input == 'inventry' && input == item['password']) {
          Navigator.of(context).push(MaterialPageRoute(builder: (context) {
            return const Inventry();
          }));
        }
      }

      if (_input == author['UserId'] && input == author['Pass']) {
        print(1);
        Navigator.of(context).push(MaterialPageRoute(builder: (context) {
          return const BillerPage();
        }));
      }

      if (_input != author['UserId'] && input != author['Pass']) {
        print(1);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          duration: Duration(seconds: 5),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
          content: Text('Enter the Valid UserId & Password'),
        ));
      }
    }
    loginhistory.add({
      'User Id ': _input,
      'Type': 'Login',
      'Date': DateTime.now().toString(),
    });
 
    sref!.setString('login History', jsonEncode(loginhistory));
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(
          vertical: MediaQuery.of(context).size.height * 0.25,
          horizontal: MediaQuery.of(context).size.width * 0.1),
      child: Card(
        shadowColor: Colors.black,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        elevation: 50.0,
        child: Container(
          padding: EdgeInsets.all(10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                "Login",
                style: TextStyle(color: Colors.black, fontSize: 20),
              ),
              Form(
                  key: _formKey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      TextFormField(
                        onChanged: (value) {
                          setState(() {
                            _input = value;
                          });
                        },
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Enter User ID';
                          }
                          return null;
                        },
                        decoration: InputDecoration(
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15)),
                            labelText: 'User ID',
                            labelStyle: TextStyle(color: Colors.black),
                            hintText: 'Enter User ID'),
                        controller: textController,
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.04,
                      ),
                      TextFormField(
                        obscureText: true,
                        onChanged: (value) {
                          setState(() {
                            input = value;
                          });
                        },
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Enter Valid Password';
                          }
                          return null;
                        },
                        decoration: InputDecoration(
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15)),
                            labelText: 'Password',
                            labelStyle: TextStyle(color: Colors.black),
                            hintText: 'Enter Password'),
                        controller: passwordController,
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.04,
                      ),
                      ElevatedButton(
                          onPressed: () {
                            _submit();
                       
                          },
                          child: Text('Login')),
                    ],
                  ))
            ],
          ),
        ),
      ),
    );
  }
}
