import 'dart:convert';

import 'package:flutter/material.dart';
// import 'package:meddapp/customwidget.dart';
import 'package:shared_preferences/shared_preferences.dart';

class StockEntry1 extends StatefulWidget {
  const StockEntry1({super.key});

  @override
  State<StockEntry1> createState() => _StockEntryState();
}

class _StockEntryState extends State<StockEntry1> {
  @override
  void initState() {
    super.initState();
    fetchData();
  }

  SharedPreferences? sref;
  List? medicineMaster;
  List? stock;
  fetchData() async {
    sref = await SharedPreferences.getInstance();
    String data = sref!.getString('medicineMaster') ?? '[]';
    String data1 = sref!.getString('stock') ?? '[]';
    medicineMaster = jsonDecode(data);
    stock = jsonDecode(data1);

    setState(() {});
  }

  void addStockEntry(String medName, String brand) {
    bool isMedicineExist = medicineMaster!.any(
        (item) => item['Medicine Name'] == medName && item['Brand'] == brand);

    if (!isMedicineExist) {
      Map dummy = {'Medicine Name': medName, 'Brand': brand};
      medicineMaster!.add(dummy);

      updateDropdownOptions();
    }
    setState(() {
      sref!.setString('medicineMaster', jsonEncode(medicineMaster));
    });
  }

  void updateStockEntry(String medName, String quantity, String netPrice) {
    bool isStockUpdated = false;
    for (var item in stock!) {
      if (item['Medicine Name'] == medName) {
        int totalqty = int.parse(item['quantity']) + int.parse(quantity);
        item['quantity'] = totalqty.toString();
        item['Unit Price'] = netPrice;
        isStockUpdated = true;
        break;
      }
    }
    if (!isStockUpdated) {
      Map newItem = {
        'Medicine Name': medName,
        'quantity': quantity,
        'Unit Price': netPrice,
      };
      stock!.add(newItem);
    }
    setState(() {});
    updateDropdownOptions();
  }

  List options = [];
  void updateDropdownOptions() {
    options = medicineMaster!.map((e) => e['Medicine Name']).toList();
  }

  bool isDropDown = true;
  TextEditingController brndController = TextEditingController();
  TextEditingController medController = TextEditingController();
  final medKey = GlobalKey<FormState>();
  TextEditingController qtyController = TextEditingController();
  TextEditingController priceController = TextEditingController();
  final updateKey = GlobalKey<FormState>();
  String? selectedOption;

  @override
  Widget build(BuildContext context) {
    if (stock == null) {
      return Center(
        child: const CircularProgressIndicator(),
      );
    } else {
      options = medicineMaster!.map((e) => e['Medicine Name']).toList();
      return SafeArea(
        child: Padding(
          padding: EdgeInsets.all(10.0),
          child: Column(
            children: [
              Text(
                'Stock Entry',
                style: TextStyle(
                  color: Colors.blue,
                  fontSize: 25.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(
                height: 20.0,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Refill Stock',
                    style: TextStyle(
                      fontSize: 20.0,
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      showDialog(
                        context: context,
                        builder: (context) {
                          return SizedBox(
                            height: 10.0,
                            child: StatefulBuilder(
                              builder: (context, setState) {
                                return AlertDialog(
                                  contentPadding: EdgeInsets.all(10.0),
                                  content: SizedBox(
                                    height: 300.0,
                                    child: Column(
                                      children: [
                                        SizedBox(
                                          child: ListTile(
                                            leading: IconButton(
                                              onPressed: () {
                                                Navigator.pop(context);
                                              },
                                              icon: Icon(Icons.close),
                                            ),
                                            title: Text('Add Stock'),
                                          ),
                                        ),
                                        Form(
                                          key: medKey,
                                          child: Column(
                                            children: [
                                              // myform(
                                              //   icon: Icons
                                              //       .medical_information_rounded,
                                              //   text: 'Enter Medicine Name',
                                              //   ctrl: medController,
                                              // ),
                                              SizedBox(
                                                height: 10.0,
                                              ),
                                              // myform(
                                              //   icon: Icons
                                              //       .branding_watermark_rounded,
                                              //   text: 'Enter Brand',
                                              //   ctrl: brndController,
                                              // ),
                                              SizedBox(
                                                height: 10.0,
                                              ),
                                              ElevatedButton(
                                                onPressed: () {
                                                  if (medKey.currentState!
                                                      .validate()) {
                                                    setState(() {
                                                      addStockEntry(
                                                          medController.text,
                                                          brndController.text);
                                                      medController.clear();
                                                      brndController.clear();
                                                      sref!.setString(
                                                          'medicineMaster',
                                                          jsonEncode(
                                                              medicineMaster));
                                                    });
                                                    ScaffoldMessenger.of(
                                                            context)
                                                        .showSnackBar(
                                                      SnackBar(
                                                        content: Text(
                                                          'Added Sucessfully ...!!!',
                                                          style: TextStyle(
                                                              fontSize: 14.0,
                                                              color:
                                                                  Colors.white),
                                                          textAlign:
                                                              TextAlign.center,
                                                        ),
                                                        backgroundColor:
                                                            Colors.green,
                                                        elevation: 20,
                                                        shape:
                                                            RoundedRectangleBorder(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      20.0),
                                                        ),
                                                      ),
                                                    );
                                                    Navigator.pop(context);
                                                  }
                                                },
                                                child: Text("Add"),
                                              )
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                          );
                        },
                      );
                    },
                    child: Text(
                      '+ Add',
                      style: TextStyle(
                        fontSize: 20.0,
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 500.0,
                width: double.infinity,
                child: Card(
                  child: Form(
                    key: updateKey,
                    child: Padding(
                      padding: EdgeInsets.all(30.0),
                      child: Column(
                        children: [
                          DropdownButton(
                            hint: Text('Medicine Name'),
                            items:
                                options.map<DropdownMenuItem<String>>((item) {
                              return DropdownMenuItem<String>(
                                value: item,
                                child: Text(item),
                              );
                            }).toList(),
                            value: selectedOption,
                            onChanged: (newValue) {
                              setState(
                                () {
                                  selectedOption = newValue;
                                  isDropDown = false;
                                  if (selectedOption != null &&
                                      selectedOption!.isNotEmpty) {
                                    brndController.text = selectedOption!;
                                  }
                                },
                              );
                            },
                          ),
                          SizedBox(
                            height: 10.0,
                          ),
                          // myform(
                          //   icon: Icons.branding_watermark_rounded,
                          //   text: 'Brand',
                          //   ctrl: brndController,
                          //   enable: isDropDown,
                          // ),
                          SizedBox(
                            height: 10.0,
                          ),
                          // myform(
                          //     text: 'Quantity',
                          //     ctrl: qtyController,
                          //     icon: Icons.shopping_cart),
                          // SizedBox(
                          //   height: 10.0,
                          // ),
                          // myform(
                          //   text: 'Net Price',
                          //   ctrl: priceController,
                          //   icon: Icons.currency_rupee,
                          // ),
                          SizedBox(
                            height: 10.0,
                          ),
                          ElevatedButton(
                            onPressed: () {
                              if (updateKey.currentState!.validate()) {
                                updateStockEntry(selectedOption!,
                                    qtyController.text, priceController.text);
                              }
                              qtyController.clear();
                              priceController.clear();
                              setState(() {
                                sref!.setString('stock', jsonEncode(stock));
                              });
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    'update Sucessfully ...!!!',
                                    style: TextStyle(
                                        fontSize: 14.0, color: Colors.white),
                                    textAlign: TextAlign.center,
                                  ),
                                  backgroundColor: Colors.green,
                                  elevation: 20,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20.0),
                                  ),
                                ),
                              );
                            },
                            child: Text('Update'),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      );
    }
  }
}
