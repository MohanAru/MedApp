import 'dart:convert';
import 'dart:math';

import 'package:autocomplete_textfield/autocomplete_textfield.dart';
import 'package:flutter/material.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:medapp/StockView.dart';
import 'package:medapp/details.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BillEntry extends StatefulWidget {
  const BillEntry({super.key});

  @override
  State<BillEntry> createState() => _BillEntryState();
}

class _BillEntryState extends State<BillEntry> {
  String? sales;
  TextEditingController textFieldController1 = TextEditingController();
  TextEditingController textFieldController2 = TextEditingController();
  GlobalKey<AutoCompleteTextFieldState<String>> key = GlobalKey();
  SharedPreferences? sref;
  // List<Map<String, dynamic>> filteredMedicineData = [];
  List<Map<String, dynamic>> filteredMedicineData1 = [];

  Future<List<String>> getMedicineList() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? savedList = prefs.getStringList('medicinelist');
    if (savedList != null) {
      return savedList;
    } else {
      return [];
    }
  }

  List<String>? medicinelist;
  void getMed() async {
    medicinelist = await getMedicineList();
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // initializeSharedPreferences();
    // getsales();
    getMed();
    getmedicineList();
  }

  List<Map<String, dynamic>>? medicineData;
  void getmedicineList() async {
    medicineData = await medMaplist();
  }

  Future<List<Map<String, dynamic>>> medMaplist() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? jsonData = prefs.getString('medicineData');
    if (jsonData != null) {
      List<dynamic> data = jsonDecode(jsonData);
      return List<Map<String, dynamic>>.from(data);
    } else {
      return [];
    }
  }

//! Save data to SharedPreferences
  void saveData(String key, String value) async {
    print(filteredMedicineData1[0]['Unit Price'] *
        int.parse(textFieldController2.text));
    SharedPreferences prefs = await SharedPreferences.getInstance();
    try {
      final String currentValueString = prefs.getString(key) ?? '0';

      // Validate the current value string before parsing it.
      if (RegExp(r'^-?\d*(\.\d+)?$').hasMatch(currentValueString)) {
        double currentValue = double.parse(currentValueString);

        final double parsedValue = double.tryParse(value) ?? 0.0;

        final double newValue = currentValue + parsedValue;

        prefs.setString(key, newValue.toString());
        setState(() {});
      } else {
        print("Error: Invalid format for currentValueString");
      }
    } catch (e) {
      // Handle the exception
      print("Error: $e");
    }
  }

  void billgenerate() {
    //!  Alert Box for Confirm the sales
    Future.delayed(Duration(seconds: 1), () {
      showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) {
          return AlertDialog(
            actions: <Widget>[
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Order Placed',
                    style: TextStyle(color: Color.fromARGB(255, 10, 173, 198)),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Flexible(
                        child: RichText(
                            text: TextSpan(children: [
                          TextSpan(
                              text: 'Order :',
                              style: TextStyle(color: Colors.red)),
                          TextSpan(
                              text: 'RF#${10000 + Random().nextInt(95680)}'),
                        ])),
                      ),
                      Flexible(
                        child: RichText(
                            text: TextSpan(children: [
                          TextSpan(
                              text: 'Medicine:',
                              style: TextStyle(color: Colors.red)),
                          TextSpan(text: textFieldController1.text),
                        ])),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  RichText(
                      text: TextSpan(children: [
                    TextSpan(
                        text: 'Quantity  : ',
                        style: TextStyle(color: Colors.blueAccent)),
                    TextSpan(text: textFieldController2.text),
                  ])),
                  const SizedBox(
                    height: 10,
                  ),
                  RichText(
                      text: TextSpan(children: [
                    TextSpan(
                        text: 'Unit Price  : ',
                        style: TextStyle(color: Colors.blueAccent)),
                    TextSpan(text: '${filteredMedicineData1[0]['Unit Price']}'),
                  ])),
                  const SizedBox(
                    height: 10,
                  ),
                  Text(
                    'Total Price',
                    style: TextStyle(color: Colors.blueAccent, fontSize: 20),
                  ),
                  Text(
                    '\$ ${filteredMedicineData1[0]['Unit Price'] * int.parse(textFieldController2.text)}',
                    style: TextStyle(color: Colors.green, fontSize: 25),
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                          textFieldController1.clear();
                          textFieldController2.clear();
                          BillDetails.saveBillDetailsList([
                            BillDetails(
                                billNo: '${10000 + Random().nextInt(95680)}',
                                medicineName: textFieldController1.text,
                                quantity: 10,
                                unitPrice: 10.0,
                                amount: 1000.0)
                          ]);
                        },
                        child: Text('Proceed Order',
                            style: TextStyle(color: Colors.white)),
                      )
                    ],
                  )
                ],
              )
            ],
          );
        },
      );
    });
  }

  void filterData1() {
    // Filter the data based on the text entered in the textFieldController.
    final searchTerm1 = textFieldController1.text.toLowerCase();
    setState(() {
      filteredMedicineData1 = medicineData!.where((data) {
        return data['Medicine Name'].toLowerCase().contains(searchTerm1) ||
            data['Brand'].toLowerCase().contains(searchTerm1) ||
            data['Quantity'].toString().contains(searchTerm1) ||
            data['Unit Price'].toString().contains(searchTerm1);
      }).toList();
      print(filteredMedicineData1);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(8.0),
        child: Column(
          children: [
            SizedBox(
              height: 10,
            ),
            Text(
              'BILL ENTRY',
              style: TextStyle(color: Colors.blue, fontSize: 16),
            ),
            SizedBox(
              height: 10.0,
            ),
            Expanded(
              child: ListView(children: [
                ExpansionTile(
                  title: Text('BILL ENTRY'),
                  tilePadding: EdgeInsets.all(8),
                  collapsedBackgroundColor: Colors.blue,
                  children: [
                    Card(
                      elevation: 4.0,
                      margin: EdgeInsets.all(16.0),
                      child: SizedBox(
                        height: MediaQuery.of(context).size.height * 0.1,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            SizedBox(
                              width: MediaQuery.of(context).size.width * 0.30,
                              height: MediaQuery.of(context).size.height * 0.08,
                              child: TypeAheadField<String>(
                                textFieldConfiguration: TextFieldConfiguration(
                                  controller: textFieldController1,
                                  decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8)),
                                      labelText: 'Select an item'),
                                ),
                                suggestionsCallback: (pattern) {
                                  return medicinelist!.where((item) => item
                                      .toLowerCase()
                                      .contains(pattern.toLowerCase()));
                                },
                                itemBuilder: (context, suggestion) {
                                  return ListTile(
                                    title: Text(suggestion),
                                  );
                                },
                                onSuggestionSelected: (suggestion) {
                                  textFieldController1.text = suggestion;
                                },
                              ),
                            ),
                            SizedBox(
                                width: MediaQuery.of(context).size.width * 0.30,
                                height:
                                    MediaQuery.of(context).size.height * 0.08,
                                child: TextFormField(
                                  controller: textFieldController2,
                                  decoration: InputDecoration(
                                    label: Text(
                                      'Quantity',
                                      style: TextStyle(fontSize: 12),
                                    ),
                                    hintText: 'Enter Value',
                                    border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(8)),
                                  ),
                                )),
                            SizedBox(
                              width: MediaQuery.of(context).size.width * 0.18,
                              height: MediaQuery.of(context).size.height * 0.05,
                              child: ElevatedButton(
                                onPressed: () {
                                  if (int.parse(textFieldController2.text) <=
                                      0) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                            'Place the Order Correctly...'),
                                        duration: Duration(seconds: 1),
                                        backgroundColor: Colors.red,
                                      ),
                                    );
                                  }
                                  if (int.parse(textFieldController2.text) >
                                      0) {
                                    filterData1();
                                    billgenerate();
                                    // saveMedicineList(medicinelist);
                                  }
                                },
                                child: Text(
                                  'ADD',
                                  style: TextStyle(fontSize: 8),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                Card(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Row(
                        children: [
                          ElevatedButton(
                              onPressed: () async {},
                              style: ButtonStyle(
                                backgroundColor: MaterialStatePropertyAll(
                                  Colors.green,
                                ),
                              ),
                              child: Text('Save'))
                        ],
                      ),
                      TextField(),
                      DataTable(
                          dataRowHeight: 30,
                          columnSpacing:
                              MediaQuery.of(context).size.width * 0.01,
                          columns: [
                            DataColumn(
                                label: Flexible(
                              child: Text(
                                'Medicine Name',
                                style: TextStyle(fontSize: 10),
                              ),
                            )),
                            DataColumn(
                                label: Text(
                              'Brand',
                              style: TextStyle(fontSize: 10),
                            )),
                            DataColumn(
                                label: Text(
                              'Quantity',
                              style: TextStyle(fontSize: 10),
                            )),
                            DataColumn(
                                label: Text(
                              'Total Price',
                              style: TextStyle(fontSize: 10),
                            )),
                          ],
                          rows: List.generate(filteredMedicineData1.length,
                              (index) {
                            return DataRow(cells: [
                              DataCell(Text(filteredMedicineData1[index]
                                  ['Medicine Name'])),
                              DataCell(
                                  Text(filteredMedicineData1[index]['Brand'])),
                              DataCell(
                                  Text(textFieldController2.text.toString())),
                              DataCell(Text((filteredMedicineData1[index]
                                          ['Unit Price'] *
                                      int.parse(textFieldController2.text))
                                  .toString())),
                            ]);
                          })),
                    ],
                  ),
                ),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}
