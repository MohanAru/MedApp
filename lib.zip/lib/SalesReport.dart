import 'dart:convert';

import 'package:flutter/material.dart';

import 'package:medapp/details.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SalesReport extends StatefulWidget {
  const SalesReport({super.key});

  @override
  State<SalesReport> createState() => _SalesReportState();
}

class _SalesReportState extends State<SalesReport> {
  TextEditingController textFieldController = TextEditingController();
  TextEditingController textFieldController1 = TextEditingController();
  DateTime fromDate = DateTime.now();
  DateTime toDate = DateTime.now();

  Future<void> _selectDate(BuildContext context, bool isFromDate) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: isFromDate ? fromDate : toDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null) {
      setState(() {
        if (isFromDate) {
          fromDate = picked;
        } else {
          toDate = picked;
        }
      });
    }
  }

  //! List<BillDetails> Data From Details
  static Future<List<BillDetails>> getBillDetailsList() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonData = prefs.getString('billDetailsList');
    // print(prefs.containsKey('billDetailsList'));
    if (jsonData != null) {
      List<dynamic> data = jsonDecode(jsonData);
      print(data);
      List<Map<String, dynamic>> mapList =
          List<Map<String, dynamic>>.from(data);

      return mapList.map((item) => BillDetails.fromMap(item)).toList();
    } else {
      return [];
    }
  }

  List<Map<String, dynamic>> filteredMedicineData = [];

  void getBillDetails() async {
    List<Map<String, dynamic>> list = [];

    List<BillDetails> billDetailsList = await getBillDetailsList();
    for (var billDetail in billDetailsList) {
      list.add(billDetail.toMap());
    }
    print(list);
  }

  @override
  void initState() {
    super.initState();
    getmedicine();
    print(medicineData);
  }

  List<Map<String, dynamic>> filteredMedicineData1 = [];
  List<Map<String, dynamic>>? medicineData;
  void getmedicine() async {
    medicineData = await getmedicineData();

    setState(() {});
  }

  Future<List<Map<String, dynamic>>> getmedicineData() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? jsonData = prefs.getString('medicineData');
    if (jsonData != null) {
      List<dynamic> data = jsonDecode(jsonData);

      return List<Map<String, dynamic>>.from(data);
    }
    if (jsonData == null) {
      return [];
    }
    return [];
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ListView(children: [
        Column(
          children: [
            SizedBox(
              height: 10,
            ),
            Text(
              'Sales Report',
              style: TextStyle(color: Colors.blue, fontSize: 18),
            ),
            SizedBox(
              height: 10.0,
            ),
            Card(
              elevation: 4.0,
              margin: EdgeInsets.all(16.0),
              child: SizedBox(
                height: MediaQuery.of(context).size.height * 0.3,
                width: MediaQuery.of(context).size.width * 0.8,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.30,
                      height: MediaQuery.of(context).size.height * 0.08,
                      child: TextFormField(
                        readOnly: true,
                        onTap: () => _selectDate(context, true),
                        decoration: InputDecoration(
                          labelText: 'From Date',
                          prefixIcon: Icon(Icons.calendar_today),
                        ),
                        controller: TextEditingController(
                          text: "${fromDate.toLocal()}".split(' ')[0],
                        ),
                      ),
                    ),
                    SizedBox(
                        width: MediaQuery.of(context).size.width * 0.30,
                        height: MediaQuery.of(context).size.height * 0.08,
                        child: TextFormField(
                          readOnly: true,
                          onTap: () => _selectDate(context, false),
                          decoration: InputDecoration(
                            labelText: 'To Date',
                            prefixIcon: Icon(Icons.calendar_today),
                          ),
                          controller: TextEditingController(
                            text: "${toDate.toLocal()}".split(' ')[0],
                          ),
                        )),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.18,
                      height: MediaQuery.of(context).size.height * 0.05,
                      child: ElevatedButton(
                        onPressed: () {
                          getBillDetails();
                        },
                        child: Text(
                          'Search',
                          style: TextStyle(fontSize: 8),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
            Card(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.max,
                children: [
                  TextField(),
                  DataTable(
                      dataRowHeight: 30,
                      columnSpacing: MediaQuery.of(context).size.width * 0.05,
                      columns: [
                        const DataColumn(
                            label: Flexible(
                          child: Text(
                            'Bill NO',
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 10),
                          ),
                        )),
                        const DataColumn(
                            label: Flexible(
                          child: Text(
                            'Bill Date',
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 10),
                          ),
                        )),
                        const DataColumn(
                            label: Flexible(
                          child: Text(
                            'Medicine Name',
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 10),
                          ),
                        )),
                        const DataColumn(
                            label: Text(
                          'Quantity',
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 10),
                        )),
                        const DataColumn(
                            label: Text(
                          'Amount',
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 10),
                        )),
                      ],
                      rows:
                          List.generate(filteredMedicineData1.length, (index) {
                        return DataRow(cells: [
                          DataCell(Text(
                              filteredMedicineData1[index]['Medicine Name'])),
                          DataCell(Text(filteredMedicineData1[index]['Brand'])),
                          DataCell(Text(textFieldController1.text.toString())),
                          DataCell(Text((filteredMedicineData1[index]
                                      ['Unit Price'] *
                                  int.parse(textFieldController1.text))
                              .toString())),
                        ]);
                      })),
                ],
              ),
            )
          ],
        ),
      ]),
    );
  }
}
