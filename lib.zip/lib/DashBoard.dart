import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DashBoard extends StatefulWidget {
  const DashBoard({super.key});

  @override
  State<DashBoard> createState() => _DashBoardState();
}

class _DashBoardState extends State<DashBoard> {
  bool isLoad = false;
  String? sales;
  void getsales() async {
    sales = await getData("sales");
    isLoad=true;
    setState(() {
      
    });
  }

// Retrieve data from SharedPreferences
  Future<String?> getData(String key) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    // Check if SharedPreferences is initialized
    if (sales == null ) {
      return '0'; // Handle this case appropriately
    }

    return prefs.getString(key) ?? '0';
  }
  @override
  void initState() {
    super.initState();
    getsales();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(25),
      child: Card(
        elevation: 4.0,
        shadowColor: Colors.black,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Container(
          height: MediaQuery.of(context).size.height * 0.25,
          width: MediaQuery.of(context).size.width * 0.80,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Your Sales Today',
                style: TextStyle(color: Colors.blue, fontSize: 20),
              ),
              isLoad
                  ? Text('\$ $sales'!,
                      style: TextStyle(color: Colors.greenAccent, fontSize: 25))
                  : CircularProgressIndicator(),
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.1,
              )
            ],
          ),
        ),
      ),
    );
  }
}
