

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:medapp/DashBoard.dart';

class DashBoard1 extends StatefulWidget {
  const DashBoard1({super.key});

  @override
  State<DashBoard1> createState() => _DashBoard1State();
}

class _DashBoard1State extends State<DashBoard1> {
  @override
  Widget build(BuildContext context) {
    return Center(child: ListView(
      children: [Column(children: [
        DashBoard(),
        Card(elevation: 4.0,),
        SizedBox(
          height: 250,
          child: LineChart(
          LineChartData(
            gridData: FlGridData(show: false),
            titlesData: FlTitlesData(show: false),
            borderData: FlBorderData(
              show: true,
              border: Border.all(
                color: const Color(0xff37434d),
                width: 1,
              ),
            ),
            minX: 0,
            maxX: 11,
            minY: 0,
            maxY: 1000, // Adjust the max value based on your sales data.
            lineBarsData: [
              LineChartBarData(
                spots: [
                  FlSpot(0, 300), // January
                  FlSpot(1, 450), // February
                  FlSpot(2, 600), // March
                  // Add data for each month
                ],
                isCurved: true,
                colors: [Colors.blue],
                dotData: FlDotData(show: false),
                belowBarData: BarAreaData(show: false),
              ),
            ],
          ),
            ),
        )
      ],),]
    ),);
  }
}